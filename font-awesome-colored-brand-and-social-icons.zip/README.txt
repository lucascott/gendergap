A Pen created at CodePen.io. You can find this one at https://codepen.io/ameyraut/pen/yfzog.

 Font Awesome Brand and social Icons with brand color